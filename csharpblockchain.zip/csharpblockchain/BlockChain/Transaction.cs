﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace BlockChainDemo
{
    /// <summary>
    /// класс транзакции - содержит информацию об одной транзакции
    /// </summary>
    [Serializable]
    public class Transaction
    {
        public int mark { get; set; } //оценка
        public string studentName { get; set; } //имя
        public string subject { get; set; } //предмет

        public string group { get; set; } //группа
        public int course { get; set; } // номер курса
    }
}