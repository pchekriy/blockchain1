﻿using Newtonsoft.Json;
using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Http;

namespace BlockChainDemo
{/// <summary>
/// класс вэб-сервер
/// </summary>
    public class WebServer
    {
        public WebServer(BlockChain chain)
        {
            //создание localhost
            var settings = ConfigurationManager.AppSettings;
            string host = settings["host"]?.Length > 1 ? settings["host"] : "localhost";
            string port = settings["port"]?.Length > 1 ? settings["port"] : "12345";


            var server = new TinyWebServer.WebServer(request =>
            {
                //разбиение ссылки на Path And Query
                string path = request.Url.PathAndQuery.ToLower();
                string query = "";
                string json = "";
                string resp;
                if (path.Contains("?"))
                {
                    string[] parts = path.Split('?');
                    path = parts[0];
                    query = parts[1];
                }
                //свитчкэйз разных команд
                switch (path)
                {
                    //GET: http://localhost:12345/mine
                    //Запрос на майнинг нового блока
                    case "/mine":
                        resp = chain.Mine();
                        Settings.Save(chain);//запись цепи после майнинга в файл
                        return resp;

                    //POST: http://localhost:12345/transactions/new
                    //{ "studentName": "Mark","group":" BSE-191","course":1,"subject":" Algebra","mark": 6}

                    case "/transactions/new":
                        //запись новой транзакции
                        if (request.HttpMethod != HttpMethod.Post.Method)
                            return $"{new HttpResponseMessage(HttpStatusCode.MethodNotAllowed)}";

                        try
                        {
                            json = new StreamReader(request.InputStream).ReadToEnd();
                            Transaction trx = JsonConvert.DeserializeObject<Transaction>(json);
                            int blockId = chain.CreateTransaction(trx);
                            Settings.Save(chain);
                            return $"Your transaction will be included in block {blockId}";
                        }
                        catch (Exception e)
                        {
                            return $"Неверный формат";
                        }
                    //GET: http://localhost:12345/chain
                    case "/chain":
                        resp = chain.GetFullChain();
                        Settings.Save(chain);
                        return resp;
                

                }

                return "";
            },
                $"http://{host}:{port}/mine/",
                $"http://{host}:{port}/transactions/new/",
                $"http://{host}:{port}/chain/"
            );
            //пуск сервера
            server.Run();
        }
    }
}
