﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace BlockChainDemo
{
    /// <summary>
    /// класс блокчейн
    /// </summary>

    [Serializable]
    public class BlockChain
    {
        private List<Transaction> _currentTransactions = new List<Transaction>();
        private List<Block> _chain = new List<Block>();

        private Block _lastBlock => _chain.Last();



        /// <summary>
        /// конструктор без параметров - создает нулевой блок
        /// </summary>
        public BlockChain()
        {

            CreateNewBlock(proof: 100, previousHash: "1"); //создание нулевого блока
        }


        /// <summary>
        /// проверка цепи на корректность
        /// 
        /// </summary>
        /// <param name="chain"> цепь</param>
        /// <returns></returns>

        private bool IsValidChain(List<Block> chain)
        {
            Block block = null;
            Block lastBlock = chain.First();
            int currentIndex = 1;
            while (currentIndex < chain.Count)
            {
                block = chain.ElementAt(currentIndex);
                Debug.WriteLine($"{lastBlock}");
                Debug.WriteLine($"{block}");
                Debug.WriteLine("----------------------------");

                //проверка корректности предыдущего хэша
                if (block.PreviousHash != GetHash(lastBlock))
                    return false;

                //проверка корректности алгоритма  Proof of Work
                if (!IsValidProof(lastBlock.Proof, block.Proof, lastBlock.PreviousHash))
                    return false;

                lastBlock = block;
                currentIndex++;
            }

            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="proof"></param>
        /// <param name="previousHash"></param>
        /// <returns></returns>

        private Block CreateNewBlock(int proof, string previousHash = null)
        {
            var block = new Block
            {
                Index = _chain.Count,
                Timestamp = DateTime.UtcNow,
                Transactions = _currentTransactions.ToList(),
                Proof = proof,
                PreviousHash = previousHash ?? GetHash(_chain.Last())
            };

            _currentTransactions.Clear();
            _chain.Add(block);
            return block;
        }
        /// <summary>
        /// создание  доказательства работы нового блока
        /// </summary>
        /// <param name="lastProof"> последнее доказательство</param>
        /// <param name="previousHash"> последний хэш</param>
        /// <returns></returns>
        private int CreateProofOfWork(int lastProof, string previousHash)
        {
            int proof = 0;
            while (!IsValidProof(lastProof, proof, previousHash))
                proof++;

            return proof;
        }
        /// <summary>
        /// проверка корректности доказательства работы
        /// </summary>
        /// <param name="lastProof"> последнее доказательство работы</param>
        /// <param name="proof">проверяемое доказательство</param>
        /// <param name="previousHash">последний хэш</param>
        /// <returns></returns>
        private bool IsValidProof(int lastProof, int proof, string previousHash)
        {
            string guess = $"{lastProof}{proof}{previousHash}";
            string result = GetSha256(guess);
            return result.StartsWith("0000");
        }
        /// <summary>
        /// получить хэш блока
        /// </summary>
        /// <param name="block">блок</param>
        /// <returns></returns>
        private string GetHash(Block block)
        {
            string blockText = JsonConvert.SerializeObject(block);
            return GetSha256(blockText);
        }
        /// <summary>
        /// хэш 256
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string GetSha256(string data)
        {
            var sha256 = new SHA256Managed();
            var hashBuilder = new StringBuilder();

            byte[] bytes = Encoding.Unicode.GetBytes(data);
            byte[] hash = sha256.ComputeHash(bytes);

            foreach (byte x in hash)
                hashBuilder.Append($"{x:x2}");

            return hashBuilder.ToString();
        }

        //вызов вэб сервером
        internal string Mine()
        {
            int proof = CreateProofOfWork(_lastBlock.Proof, _lastBlock.PreviousHash);
           
            Block block = CreateNewBlock(proof /*, _lastBlock.PreviousHash*/);

            var response = new
            {
                Message = "New Block Forged",
                Index = block.Index,
                Transactions = block.Transactions.ToArray(),
                Proof = block.Proof,
                PreviousHash = block.PreviousHash
            };

            return JsonConvert.SerializeObject(response);
        }
        /// <summary>
        /// вывести полную цепочку
        /// </summary>
        /// <returns></returns>
        internal string GetFullChain()
        {
            var response = new
            {
                chain = _chain.ToArray(),
                length = _chain.Count
            };

            return JsonConvert.SerializeObject(response);
        }



        /// <summary>
        /// добавить транзакцию
        /// </summary>
        /// <param name="transaction"></param>
        /// <returns></returns>

        internal int CreateTransaction(Transaction transaction)
        {

            _currentTransactions.Add(transaction);

            return _lastBlock != null ? _lastBlock.Index + 1 : 0;
        }
    }
    /// <summary>
    /// класс для сериализиции цепи
    /// </summary>
    


}


