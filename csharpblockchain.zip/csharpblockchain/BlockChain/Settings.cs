﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace BlockChainDemo
{
    public static class Settings
    {
        const string fileName = "blockchain.blk";
        const int VERSION = 1;
        public static void Save(BlockChain blockChain)
        {
            Stream stream = null;
            try
            {
                IFormatter formatter = new BinaryFormatter();
                stream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(stream, VERSION);
                formatter.Serialize(stream, blockChain);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (null != stream)
                    stream.Close();
            }
        }

        public static bool Exists()
        {
            return File.Exists(fileName);
        }

        public static BlockChain Load()
        {
            Stream stream = null;
            BlockChain settings = null;
            try
            {
                IFormatter formatter = new BinaryFormatter();
                stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.None);
                int version = (int)formatter.Deserialize(stream);
                Debug.Assert(version == VERSION);
                settings = (BlockChain)formatter.Deserialize(stream);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (null != stream)
                    stream.Close();
            }
            return settings;
        }
    }
}
