﻿
using System.Xml.Linq;
using System.IO;

namespace BlockChainDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Starting Blockchain");
            BlockChain chain;   
            if (Settings.Exists())
            {
                chain = Settings.Load();
            } else
            {
                chain = new BlockChain();
            }  
           
            var server = new WebServer(chain);
           
            System.Console.Read();
           
        }
    }
}
